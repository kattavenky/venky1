﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BANKINGAPP.Models;
namespace BANKINGAPP.Controllers
{
 public class AdminsController : Controller
    {
        // GET: Admins
        pubsEntities pe = new pubsEntities();
        public ActionResult Index()
        {
            return View();
     }
        [HttpPost]
public ActionResult Index(Bank_Master bm)
        {
            if (ModelState.IsValid)
            {
                pe.Entry(bm).State = System.Data.Entity.EntityState.Added;
                pe.SaveChanges();
                return RedirectToAction("Index", "Admins");
            }
            else
            {
                return View("Index");
            }
        }
public ActionResult Logout()
        {
          Session.Clear();
          return RedirectToAction("Index", "Home");
        }
    }
}