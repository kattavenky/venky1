﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BANKINGAPP.Models;
namespace BANKINGAPP.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult CheckLogin(FormCollection fc)
        {
            using (pubsEntities pe = new pubsEntities())
            {
                Bank_Admin ba = new Bank_Admin();
                string ur = fc["Ad"].ToString();
                string pd = fc["pwd"].ToString();
                if (ur == "Admin" && pd == "123")
                {
                    return RedirectToAction("Index", "Admins");
                }
                else
                {
                    return RedirectToAction("Index", "Users");
                }
            }
        }
    }
}