﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BANKINGAPP.Models;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
namespace BANKINGAPP.Controllers
{
    public class UsersController : Controller
    {
        // GET: Users
        pubsEntities pe = new pubsEntities();
        public ActionResult Index()
        {

            return View();
        }
        [HttpGet]
        public ActionResult Create()
        {
            string mysql = ConfigurationManager.ConnectionStrings["Mycon"].ConnectionString;
            SqlConnection conn = new SqlConnection(mysql);
            conn.Open();
            string query = "select * from Bank_Master";
            SqlCommand cmd = new SqlCommand(query, conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            ViewBag.AcType = ds.Tables[0];
            List<SelectListItem> getType = new List<SelectListItem>();
            foreach (System.Data.DataRow item in ViewBag.AcType.Rows)
            {
                getType.Add(new SelectListItem { Text = @item["AcType"].ToString(), Value = @item["AcType"].ToString() });
                ViewBag.type1 = getType;
            }                     
            return View();
        }
        [HttpPost]
        public ActionResult Create(CustomerDetail cd)
        {
            if (ModelState.IsValid)
            {
                pe.Entry(cd).State = System.Data.Entity.EntityState.Added;
                cd.BalanceAmount = 500;//default amount to added while creating new ac
                pe.SaveChanges();
                return RedirectToAction("Index", "Users");
            }
            else
            {
                return RedirectToAction("Index", "Users");
            }
        }
        public ActionResult Signout()
        {
            return RedirectToAction("Index", "Users");
        }
        [HttpGet]
        public ActionResult Operations()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Operations(int id)
        {
            CustomerDetail cd = pe.CustomerDetails.Find(id);
            return View("Details",cd);
        }       
        public ActionResult Details()
        {         
            return View();
        }        
        [HttpGet]       
        public ActionResult Deposit(int id)
        {
            CustomerDetail cd = pe.CustomerDetails.Where(x => x.AccountNo == id).FirstOrDefault();
            Session["i"] = cd.AccountNo;
            Session["cu_name"] = cd.CustomerName;
            Session["a"] = cd.Address;
            Session["ba"] = cd.BalanceAmount;
            Session["p"] = cd.PhoneNo;
            Session["type"] = cd.AccountType;
            Session["ac_id"] = cd.AcTypeID;
      Session["bm"] =  cd.Bank_Master;
            return View(cd);
        }        
        [HttpPost]        
        public ActionResult Deposit(CustomerDetail  cd,decimal amount)
        {          
            cd.AccountNo = int.Parse(Session["i"].ToString());
            cd.CustomerName = Session["cu_name"].ToString();
            cd.Address = Session["a"].ToString();
            cd.PhoneNo = int.Parse(Session["p"].ToString());
            decimal t = decimal.Parse(Session["ba"].ToString());
            decimal x = amount;
            t = t + x;
            cd.BalanceAmount = t;
            cd.AccountType = Session["type"].ToString();
            cd.AcTypeID = int.Parse(Session["ac_id"].ToString());
            if(cd.Bank_Master == null)
            {
              cd.Bank_Master = (Bank_Master)Session["bm"];
            }
            else
            {                
            }
            pe.Entry(cd).State = cd.AccountNo == 0 ? System.Data.Entity.EntityState.Added : System.Data.Entity.EntityState.Modified;
            pe.SaveChanges();
           return RedirectToAction("Operations");
        }      
        
    }
}
